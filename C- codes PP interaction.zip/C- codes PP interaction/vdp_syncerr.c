/* Non-reciprocal interaction Landau-stuart */
/* Case -II two different competing interactions*/
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<limits.h>

#define MAX_SIZE 101

int i,j,k,nn=10, n=3;
int l,m;
double lambda, eps1;
double meanx, meany;
double mu, eps;
double y[110][220], yy[110][220];
double p, pc;
double a[25][25], arr[25][25];


void RK4(int,int,double,double,double[110][220], double[110][220],
                   void (*DGL)(double,double[110][220],double[110][220]),
                   void (*DGL1)(double,double[110][220],double[110][220]));
void DGL(double, double[110][220],double[110][220]);
void DGL1(double, double[110][220],double[110][220]);

/*--------------------------------------------------------*/
int shuffle(int a[][nn], int nn){
int i,j;

int rr =0;
int rc=0;

  for (int i= 0; i < nn; i++){
     for (int j = 0; j < nn; j++){
        rr  = rand()%nn;
        rc = rand()%nn;
         int temp =  a[i][j];
         a[i][j] =  a[rr][rc];
         a[rr][rc] = temp;
     }
  }
}
/****************************************/  



/****************************function to generate random coupling matrices***********/

void assign(int row, int col, int arr[row][col])
{
    srand(time(0));
    
    for(int i = 0; i < row; i++){
       for(int j = 0; j < col; j++){
             if (i < pc && j< pc)
                arr[i][j] = 1;
             else
                arr[i][j] =0;      
              shuffle(arr,nn);  
          }    
       } 
}
/*********************************************************/
void main()
{
//nn= no 0f oscillators, n=dimension of the model//
double t,h,pi;
double z[20000];
double amplitude,vmin,vmax,c_max,c_min;
double x_max,x_min;
double syn_err;


FILE *fp1,*fp2, *fp3, *fp4;
fp1 = fopen("syn_err.dat","w");



for(pc = 1; pc <= 10; pc += 1) {

   double p = pc/(float) nn;
   printf("%f \n", p);


for(j=1;j < nn;j++)
 {
   y[j][1]=(float) rand()/(double)RAND_MAX*-4.0+2.0;   
   y[j][2]= (float) rand()/(double)RAND_MAX*-4.0+2.0; 
   y[j][3] = 0.05;
   
   yy[j][1]=(float) rand()/(double)RAND_MAX*-4.0+2.0;   
   yy[j][2]= (float) rand()/(double)RAND_MAX*-4.0+2.0; 
   yy[j][3] = 0.05;
  }
  
 mu=1.0;
 
 eps = 2.0;
 eps1 = 2.0;
 lambda = 3.0;
//***time step***//
h=0.01; t=0.0;

//----------------------------------------------//

for(k=1;k<=10000;k++)
   {               
      t=h*(double)(k);
      RK4(nn,n,h,t,y,yy,DGL,DGL1);  
            
     for(j=1;j<=nn;j++)
       {     
	if(k>=6000)
	  {          
         syn_err =  sqrt(pow((y[j][1] - yy[j][1]),2)+ pow((y[j][2]-yy[j][2]),2));
   
         fprintf(fp1,"%f  %f   %f   %f  %f  \n", p, yy[j][1], y[j][2], syn_err, t);
           
            }
	}    
  }
}



printf("process over!!\n");
}
/***********************RK4 SUBROUTINE*********************************/
void RK4(int nn,int n,double h,double t,double y[110][220], double yy[110][220],
	   void (*DGL)(double,double[110][220],double[110][220]),
	    void (*DGL1)(double,double[110][220],double[110][220]))
   
      {   
	   double k1[110][220],k2[110][220],k3[110][220],k4[110][220];
	   double yaux[110][220];

/*	   double kk1[110][220],kk2[110][220],kk3[110][220],kk4[110][220];*/
/*	   double yaux1[110][220];*/
	  
	  
	   DGL(t,y,k1);
	   for(j=1;j<=nn;j++)
	   {
          for(i=1;i<=n;i++)
	    yaux[j][i]=y[j][i]+h*k1[j][i]/2.0;
	   }
	   
	   
	   DGL1(t,yy,k1);
	   for(j=1;j<=nn;j++)
	   {
           for(i=1;i<=n;i++)
	     yaux[j][i]=yy[j][i]+h*k1[j][i]/2.0;
	   }
	   
	   
	   DGL(t+h/2.0,yaux,k2);
	   for(j=1;j<=nn;j++)
	   {
          for(i=1;i<=n;i++)
	    yaux[j][i]=y[j][i]+h*k2[j][i]/2.0;
	   }
	   
	  DGL1(t+h/2.0,yaux,k2);
	   for(j=1;j<=nn;j++)
	   {
          for(i=1;i<=n;i++)
	    yaux[j][i]=yy[j][i]+h*k2[j][i]/2.0;
	   }
	   
	   
	  DGL(t+h/2.0,yaux,k3);
	   for(j=1;j<=nn;j++)
	    {
            for(i=1;i<=n;i++)
	      yaux[j][i]=y[j][i]+h*k3[j][i];
	    }   

	    
	  DGL1(t+h/2.0,yaux,k3);
	   for(j=1;j<=nn;j++)
	   {
            for(i=1;i<=n;i++)
	      yaux[j][i]=yy[j][i]+h*k3[j][i];
	   }
	   
	   
	   DGL(t+h,yaux,k4);
	   for(j=1;j<=nn;j++)
	   {
             for(i=1;i<=n;i++)
	       y[j][i]=y[j][i]+h*((k1[j][i]+2*k2[j][i]+2*k3[j][i]+k4[j][i])/6.0);
	   }
	  
	   DGL1(t+h,yaux,k4);
	   for(j=1;j<=nn;j++)
	    {
             for(i=1;i<=n;i++)
	       yy[j][i]=yy[j][i]+h*((k1[j][i]+2*k2[j][i]+2*k3[j][i]+k4[j][i])/6.0);
	    }	   
	   
}
//*******************************************RK41 subroutine********************/


//*********************FUNCTION SUBROUTINE********************************//
void DGL(double t,double y[110][220], double F[110][220])
 {
 
    int i,j;
    int row = nn;
    int col = nn;
    int arr[row][col];
 
  double meanx = 0.0;
  for(j =1;j<=nn; j++)
     meanx += y[j][1];
     
     meanx = meanx/nn;   
   //  printf("%f  \n", meanx);

   
 double meany = 0.0;
  for(j =1;j<=nn; j++)
     meany += yy[j][1];
     
     meany = meany/nn;
   //  printf("%f  \n", meany);
  
  
  assign(row, col, arr);
   

for(j=1;j<=nn;j++)
   {     
  for(i=1;i<=nn;i++)
    {
  F[j][1]= y[j][2]  + eps*arr[j][i]*(y[i][1] - y[j][1]) + eps1*(meany - meanx) + lambda*y[j][3];
  F[j][2]= -mu*y[j][2]*(y[j][1]*y[j][1]-1) - y[j][1];
  F[j][3]=  -meanx - meany - y[j][3]; 
   }
}

}


//-------------------------------------------------------------//

void DGL1(double t,double yy[110][220], double F[110][220])
 {
 
    int i,j;
    int row = nn;
    int col = nn;
    int arr[row][col];
 
  
  double meanx = 0.0;
  for(j =1;j<=nn; j++)
     meanx += y[j][1];
     
     meanx = meanx/nn;   
  //   printf("%f  \n", meanx);

   
 double meany = 0.0;
  for(j =1;j<=nn; j++)
     meany += yy[j][1];
     
     meany = meany/nn;
    // printf("%f  \n", meany);
     
     
       assign(row, col, arr);


  F[j][1]= yy[j][2]  + eps*arr[j][i]*(yy[i][1] - yy[j][1]) + eps1*(meanx - meany) + lambda*yy[j][3];
  F[j][2]= -mu*yy[j][2]*(yy[j][1]*yy[j][1]-1) - yy[j][1];
  F[j][3] = -meanx -meany - yy[j][3];
}








/*****************************************************
double f(double mu)
{  
       mu = (float) rand()/(double)RAND_MAX*-1.0+0.5;
      
 return mu;
}
/***********************************************/



/*  for(j =1 ; j<=nn; j++)*/
/*     { */
/*         par[j] = f(mu); */
/*         printf("%f \n", par[j]);*/
/*        }*/
