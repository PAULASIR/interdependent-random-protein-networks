#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<unistd.h> // UNIX standard function definitions
#include<fcntl.h>
#include<limits.h>


#include<gsl/gsl_statistics_double.h>

#define SIZE 500000

int main()
{
    char *file_name;
    double arr[SIZE];
    FILE *ifp=NULL;
    int i,j,k,l,m;
    double max, n, acr;
    //double tau,acr;
    int nn=31;
    int tau;
    
    
    FILE *fp1;
    fp1 =fopen("vdpsd.dat","w");
    
    
    file_name = "acsd_vdp.dat";
    ifp =fopen(file_name,"r");
    
     if(ifp!=NULL)
        { 
         for(i=0; i <= nn; i++)
           { 
               fscanf(ifp,"%lf",&n );
               arr[i] = n; 
               printf("%lf\n", arr[i]); 
               }
          }
               
             for( tau =1 ;tau < nn-1; tau++)
               {
                  acr = gsl_stats_lag1_autocorrelation(arr, tau , nn);
                  
                //  acr = gsl_stats_variance(arr,tau,nn);
                  
                  fprintf(fp1," %d  %f \n",tau, fabs(acr));
                } 
               
                               
    fclose(ifp);
    return 0;
}
