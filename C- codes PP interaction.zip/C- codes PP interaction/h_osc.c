/********* hamonic oscillator**************/
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<complex.h>

#define N 30
double y[20],x;
void RK4(int,double,double,double[],void (*DGL)(double,double[],double[]));
void DGL(double, double[],double[]);
double complex ps, am;
double beta, om;
double alpha;

void main()
{
    long int i,k;
    int nn=2;
    double t,h,pi;
    srand(time(0));

//clrscr();

FILE *fp1;
fp1 = fopen("phase.dat","w");
/********************************************/ 

y[1]= (float) rand()/(double)RAND_MAX*-2.0+1.0; 
y[2]= (float) rand()/(double)RAND_MAX*-2.0+1.0; 

/*y[1] = 0.1;*/
/*y[2] = 0.0;*/

//parameters
   om = 0.5; 
   beta = 0.1;
   alpha =0.001;
   
/********************************************/

h=0.1;

for(i=1;i<=2000;i++)
	{
	t=h*(double)(i);
	RK4(nn,h,t,y,DGL);
	if (i <=150)
	{
 	am = cexp(y[1]*I);
	ps = cexp(y[2]*I);
	 // fprintf(fp1,"%f  %f  %f\n", cimag(am),  creal(am),t );}
	  fprintf(fp1,"%f  %f  %f \n", y[1], y[2], t );}
	}


	printf("process over!!");

}
//************************RK4 SUBROUTINE*********************************//
void RK4(int nn,double h,double t,double y[20],
	   void (*DGL)(double,double[],double[]))
{
	   int i;
	   double k1[10],k2[10],k3[10],k4[10];
	   double yaux[20];

	   DGL(t,y,k1);
	   for(i=1;i<=nn;i++)
	   {
	   yaux[i]=y[i]+h*k1[i]/2.0;
	   }
	   DGL(t+h/2.0,yaux,k2);
	   for(i=1;i<=nn;i++)
	   {
	   yaux[i]=y[i]+h*k2[i]/2.0;
	   }
	   DGL(t+h/2.0,yaux,k3);
	   for(i=1;i<=nn;i++)
	   {
	   yaux[i]=y[i]+h*k3[i];
	   }
	   DGL(t+h,yaux,k4);
	   for(i=1;i<=nn;i++)
	   {
	      y[i]=y[i]+h*((k1[i]+2*k2[i]+2*k3[i]+k4[i])/6.0);
	   }
}
//*********************FUNCTION SUBROUTINE********************************//
void DGL(double t,double y[20],double F[5])
{
  // double meanx;
    // meanx=(y[1]+y[3])/2.0;

     F[1]=  y[2] ;                                                                     
     F[2]=  -alpha*y[2] -om*y[1] - beta*y[1]*y[1]*y[1]; 

}


